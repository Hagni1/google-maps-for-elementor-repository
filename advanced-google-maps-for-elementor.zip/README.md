Advanced Google Maps For Elementor
Contributors: hagni
Tags: elementor, maps, google maps,api
Requires at least: 6.0.0
Tested up to: 6.7.2
Stable tag: 1.0.0
Requires PHP: 7.0
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html
A simple Google Maps integration for Elementor using Google JavaScript API.
